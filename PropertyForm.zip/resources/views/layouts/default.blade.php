<!DOCTYPE html>
<html lang="en">
<head>
    @include('includes.header')
</head>
<body class="c-public-form cognito-background" >
    @yield('content')
</body>
</html>